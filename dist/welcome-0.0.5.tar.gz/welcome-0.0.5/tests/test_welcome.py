from welcome import welcome

def test_welcome():
    assert welcome.banner()
