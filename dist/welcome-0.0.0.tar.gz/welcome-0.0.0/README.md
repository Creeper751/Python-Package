This is my python package!
I have already configured it to run with flake8, mypy, pytest, and tox
Is my tests passing?: ![Tests](https://github.com/Creeper751/Python-Package/actions/workflows/tests.yml/badge.svg) 