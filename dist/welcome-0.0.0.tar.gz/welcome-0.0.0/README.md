# This is my python package

I have already configured it to run with flake8, mypy, pytest, and tox
Is my tests passing?: ![Tests](https://github.com/Creeper751/Python-Package/actions/workflows/tests.yml/badge.svg)

#### I am in no way claiming that I did all on my own. I used my own code, then followed a tutuorial by @mCodingLLC.
